# El-Sharnouby Group dashboard (Streamlit)

1. Put the `sharnouby_data` folder (the 20 CSV files) next to `app.py`.
2. Install: `pip install -r requirements.txt`
3. Run: `streamlit run app.py`

Tabs: Overview, Customers, Marketing, Operations, Supply Risk Radar.
Sidebar: data folder, fiscal-year and channel filters (Overview and Customers).
Risk Radar: adjust yield loss, production cycle, handling buffer and planning date; type your real raw-material stock into the table to get order quantities; download the order calendar and the win-back list as CSV.
